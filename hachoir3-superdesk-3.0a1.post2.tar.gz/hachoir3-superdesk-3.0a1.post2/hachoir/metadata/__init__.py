from hachoir.metadata.metadata import extractMetadata

# Just import the module,
# each module use registerExtractor() method
import hachoir.metadata.archive
import hachoir.metadata.audio
import hachoir.metadata.file_system
import hachoir.metadata.image
import hachoir.metadata.jpeg
import hachoir.metadata.misc
import hachoir.metadata.program
import hachoir.metadata.riff
import hachoir.metadata.video

