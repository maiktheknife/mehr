from hachoir.parser.image.bmp import BmpFile
from hachoir.parser.image.gif import GifFile
from hachoir.parser.image.ico import IcoFile
from hachoir.parser.image.jpeg import JpegFile
from hachoir.parser.image.pcx import PcxFile
from hachoir.parser.image.psd import PsdFile
from hachoir.parser.image.png import PngFile
from hachoir.parser.image.tga import TargaFile
from hachoir.parser.image.tiff import TiffFile
from hachoir.parser.image.wmf import WMF_File
from hachoir.parser.image.xcf import XcfFile

