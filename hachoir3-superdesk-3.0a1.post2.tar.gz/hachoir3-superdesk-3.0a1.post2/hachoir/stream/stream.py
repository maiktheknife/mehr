class StreamError(Exception):
    pass

