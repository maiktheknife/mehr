VERSION = "0.5.3"
PACKAGE = "hachoir-subfile"
WEBSITE = "http://bitbucket.org/haypo/hachoir/wiki/hachoir-subfile"
LICENSE = 'GNU GPL v2'


