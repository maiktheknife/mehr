from hachoir.version import VERSION as __version__

