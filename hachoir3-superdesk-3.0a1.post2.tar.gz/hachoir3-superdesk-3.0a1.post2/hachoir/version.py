PACKAGE = "hachoir"
VERSION = "3.0a1"
WEBSITE = 'http://hachoir3.readthedocs.org/'
LICENSE = 'GNU GPL v2'
